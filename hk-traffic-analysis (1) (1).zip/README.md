# Traffic Data Collection System

This system collects traffic data from the Hong Kong government's traffic detectors API, stores it in MongoDB, and provides a monitoring dashboard.

## Project Structure

```
.
├── docker-compose.yml         # Main docker-compose configuration
├── logs/                      # Mounted volume for logs
├── collector/                 # Data collector service
│   ├── Dockerfile             # Dockerfile for collector service
│   ├── requirements.txt       # Python dependencies for collector
│   └── collector.py           # Data collection script
└── dashboard/                 # Dashboard service
    ├── Dockerfile             # Dockerfile for dashboard service
    ├── requirements.txt       # Python dependencies for dashboard
    └── app.py                 # Streamlit dashboard application
```

## Setup and Usage

### Prerequisites

- Docker and Docker Compose installed on your system
- Internet connection to access the data source

### Getting Started

1. Clone this repository or create the files as described in the project structure
2. Run the following command to start all services:

```bash
docker-compose up -d
```

This will:
- Start a MongoDB container
- Build and start the data collector container
- Build and start the Streamlit dashboard container

### Accessing the Dashboard

Once the containers are running, you can access the Streamlit dashboard at:

```
http://localhost:8501
```

### Stopping the System

To stop all containers:

```bash
docker-compose down
```

To stop and remove volumes (this will delete all collected data):

```bash
docker-compose down -v
```

## Data Structure

The system collects and stores traffic detector data with the following structure:

- `date`: The date of the data collection
- `period_from`: Start time of the collection period
- `period_to`: End time of the collection period
- `detector_id`: Unique identifier for the traffic detector
- `direction`: Direction of traffic flow
- `lane_id`: Type of lane (Fast Lane, Middle Lane, Slow Lane)
- `speed`: Traffic speed in km/h
- `occupancy`: Occupancy percentage
- `volume`: Traffic volume
- `sd`: Standard deviation
- `valid`: Data validity flag
- `last_updated`: Timestamp when the record was last updated

## Dashboard Features

The dashboard provides:

1. **Data Collection Stats**:
   - Total number of data collections
   - Total records processed
   - New vs updated records
   - Time series charts showing collection activity

2. **Traffic Data Analysis**:
   - Speed analysis by lane type
   - Traffic volume by detector
   - Summary of unique dates, detectors, and lanes
   - Sample of raw data

The dashboard auto-refreshes at configurable intervals to show the latest data.