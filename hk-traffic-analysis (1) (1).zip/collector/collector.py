import requests
import xml.etree.ElementTree as ET
import pymongo
from pymongo import MongoClient
import time
import logging
from datetime import datetime

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='/app/logs/traffic_data_collector.log',
    filemode='a'
)

# MongoDB connection details - using Docker service name
MONGO_URI = "mongodb://mongodb:27017/"
DB_NAME = "traffic_data"
COLLECTION_NAME = "speed_volume"
STATS_COLLECTION = "collection_stats"

# URL to fetch data from
DATA_URL = "https://resource.data.one.gov.hk/td/traffic-detectors/rawSpeedVol-all.xml"


def fetch_xml_data():
    """Fetch XML data from the URL"""
    try:
        response = requests.get(DATA_URL, timeout=30)
        response.raise_for_status()  # Raise an exception for HTTP errors
        return response.content
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching data: {e}")
        return None


def parse_xml_data(xml_content):
    """Parse XML data and convert to dictionary format"""
    try:
        root = ET.fromstring(xml_content)

        # Get date
        date = root.find('date').text

        result = []

        # Process each period
        for period in root.findall('.//period'):
            period_from = period.find('period_from').text
            period_to = period.find('period_to').text

            # Process each detector
            for detector in period.findall('.//detector'):
                detector_id = detector.find('detector_id').text
                direction = detector.find('direction').text

                # Process each lane
                for lane in detector.findall('.//lane'):
                    lane_id = lane.find('lane_id').text

                    # Get lane data, handle potential missing elements
                    speed = lane.find('speed')
                    speed = int(speed.text) if speed is not None and speed.text else None

                    occupancy = lane.find('occupancy')
                    occupancy = int(occupancy.text) if occupancy is not None and occupancy.text else None

                    volume = lane.find('volume')
                    volume = int(volume.text) if volume is not None and volume.text else None

                    sd = lane.find('s.d.')
                    sd = float(sd.text) if sd is not None and sd.text else None

                    valid = lane.find('valid')
                    valid = valid.text if valid is not None else None

                    # Create document for this lane
                    lane_data = {
                        "date": date,
                        "period_from": period_from,
                        "period_to": period_to,
                        "detector_id": detector_id,
                        "direction": direction,
                        "lane_id": lane_id,
                        "speed": speed,
                        "occupancy": occupancy,
                        "volume": volume,
                        "sd": sd,
                        "valid": valid,
                        "last_updated": datetime.now()
                    }

                    result.append(lane_data)

        return result
    except Exception as e:
        logging.error(f"Error parsing XML: {e}")
        return None


def store_in_mongodb(data):
    """Store the parsed data in MongoDB using upsert to prevent duplicates"""
    if not data:
        logging.warning("No data to store")
        return False

    try:
        client = MongoClient(MONGO_URI)
        db = client[DB_NAME]
        collection = db[COLLECTION_NAME]
        stats_collection = db[STATS_COLLECTION]

        operations = []
        updated_count = 0
        inserted_count = 0

        for item in data:
            # Create a unique identifier for each record
            filter_query = {
                "date": item["date"],
                "period_from": item["period_from"],
                "period_to": item["period_to"],
                "detector_id": item["detector_id"],
                "lane_id": item["lane_id"]
            }

            # Either update existing record or insert new one
            result = collection.update_one(
                filter_query,
                {"$set": item},
                upsert=True
            )

            if result.matched_count > 0:
                updated_count += 1
            elif result.upserted_id:
                inserted_count += 1

        logging.info(f"Upsert operation completed - Updated: {updated_count}, Inserted: {inserted_count}")

        # Store stats for dashboard
        stats_collection.insert_one({
            "timestamp": datetime.now(),
            "records_processed": len(data),
            "records_updated": updated_count,
            "records_inserted": inserted_count
        })

        # Create indexes if they don't exist
        collection.create_index([("date", pymongo.ASCENDING)])
        collection.create_index([("detector_id", pymongo.ASCENDING)])
        collection.create_index([
            ("date", pymongo.ASCENDING),
            ("period_from", pymongo.ASCENDING),
            ("detector_id", pymongo.ASCENDING),
            ("lane_id", pymongo.ASCENDING)
        ], unique=True)

        # Create indexes for stats collection
        stats_collection.create_index([("timestamp", pymongo.ASCENDING)])

        return True
    except Exception as e:
        logging.error(f"Error storing data in MongoDB: {e}")
        return False
    finally:
        if 'client' in locals():
            client.close()


def main():
    """Main function to run the data collection process"""
    logging.info("Starting traffic data collection")

    while True:
        try:
            start_time = time.time()

            # Fetch XML data
            xml_content = fetch_xml_data()
            if xml_content:
                # Parse XML data
                parsed_data = parse_xml_data(xml_content)

                # Store in MongoDB with upsert
                if parsed_data:
                    store_in_mongodb(parsed_data)

            # Calculate time to sleep to maintain 1-minute interval
            elapsed_time = time.time() - start_time
            sleep_time = max(0, 60 - elapsed_time)

            logging.info(f"Iteration completed in {elapsed_time:.2f} seconds, sleeping for {sleep_time:.2f} seconds")
            time.sleep(sleep_time)

        except Exception as e:
            logging.error(f"Unexpected error in main loop: {e}")
            time.sleep(60)  # Sleep for a minute before retrying


if __name__ == "__main__":
    main()