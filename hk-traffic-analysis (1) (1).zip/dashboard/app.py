import streamlit as st
import pymongo
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
import time
import os

# MongoDB connection details
MONGO_URI = "mongodb://mongodb:27017/"
DB_NAME = "traffic_data"
SPEED_COLLECTION = "speed_volume"
STATS_COLLECTION = "collection_stats"

# -------------------------- SETUP AND UTILITIES --------------------------

# Page configuration
st.set_page_config(
    page_title="Traffic Data Dashboard",
    page_icon="🚦",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Apply custom CSS
st.markdown("""
<style>
    .main-header {font-size: 2.5rem; color: #1E88E5; text-align: center; margin-bottom: 1rem;}
    .sub-header {font-size: 1.5rem; color: #0D47A1; margin-top: 1.5rem;}
    .metric-container {background-color: #f0f2f6; border-radius: 10px; padding: 1rem; text-align: center;}
    .metric-value {font-size: 2.5rem; font-weight: bold; color: #1E88E5;}
    .metric-label {font-size: 1rem; color: #666;}
    .map-container {margin-top: 2rem; margin-bottom: 2rem;}
</style>
""", unsafe_allow_html=True)

# Header
st.markdown("<h1 class='main-header'>Traffic Data Collection Dashboard</h1>", unsafe_allow_html=True)


# Helper function to display metrics in a standardized way
def display_metric(container, value, label):
    container.markdown("<div class='metric-container'>", unsafe_allow_html=True)
    container.markdown(f"<div class='metric-value'>{value}</div>", unsafe_allow_html=True)
    container.markdown(f"<div class='metric-label'>{label}</div>", unsafe_allow_html=True)
    container.markdown("</div>", unsafe_allow_html=True)


# -------------------------- DATA LOADING --------------------------

@st.cache_data
def load_detector_info():
    """Load detector info from CSV"""
    try:
        # Look for CSV in different possible locations
        csv_paths = [
            "/app/data/traffic_speed_volume_occ_info.csv",
            "data/traffic_speed_volume_occ_info.csv"
        ]

        for csv_path in csv_paths:
            if os.path.exists(csv_path):
                return pd.read_csv(csv_path)

        st.error("Could not find detector info CSV file")
        return None
    except Exception as e:
        st.error(f"Error loading detector info: {e}")
        return None


@st.cache_resource
def get_mongo_client():
    """Connect to MongoDB"""
    return pymongo.MongoClient(MONGO_URI)


@st.cache_data(ttl=60)
def get_collection_stats(time_filter):
    """Get collection statistics from MongoDB"""
    query = {"timestamp": {"$gte": time_filter}}
    return list(stats_collection.find(query).sort("timestamp", -1))


@st.cache_data(ttl=60)
def get_traffic_data(time_filter):
    """Get traffic data from MongoDB"""
    query = {"last_updated": {"$gte": time_filter}}
    return list(speed_collection.find(query).sort("last_updated", -1).limit(1000))


@st.cache_data(ttl=60)
def get_historical_data(hours_back=24, interval_minutes=30):
    """Get historical data at specified intervals for replay functionality"""
    end_time = datetime.now()
    start_time = end_time - timedelta(hours=hours_back)

    # Create timestamps at regular intervals
    timestamps = []
    current = start_time
    while current <= end_time:
        timestamps.append(current)
        current += timedelta(minutes=interval_minutes)

    # Query data for each timestamp
    historical_frames = []
    for ts in timestamps:
        query_time = ts - timedelta(minutes=interval_minutes)
        query = {"last_updated": {"$gte": query_time, "$lte": ts}}
        data = list(speed_collection.find(query))
        if data:
            frame = {
                "timestamp": ts,
                "data": data
            }
            historical_frames.append(frame)

    return historical_frames


# -------------------------- METRIC CALCULATIONS --------------------------

def calculate_metrics(stats_data):
    """Calculate summary metrics from stats data"""
    if not stats_data:
        return {
            "total_records": 0,
            "total_inserts": 0,
            "total_updates": 0,
            "total_collections": 0,
            "avg_records_per_minute": 0
        }

    total_records = sum(s.get("records_processed", 0) for s in stats_data)
    total_inserts = sum(s.get("records_inserted", 0) for s in stats_data)
    total_updates = sum(s.get("records_updated", 0) for s in stats_data)
    total_collections = len(stats_data)

    # Calculate records per minute
    if len(stats_data) > 1:
        earliest = min(s["timestamp"] for s in stats_data)
        latest = max(s["timestamp"] for s in stats_data)
        duration_minutes = (latest - earliest).total_seconds() / 60
        avg_records_per_minute = total_records / max(1, duration_minutes)
    else:
        avg_records_per_minute = total_records

    return {
        "total_records": total_records,
        "total_inserts": total_inserts,
        "total_updates": total_updates,
        "total_collections": total_collections,
        "avg_records_per_minute": avg_records_per_minute
    }


def prepare_map_data(traffic_data, detector_info, metric):
    """Prepare data for map visualization based on selected metric"""
    if not traffic_data or detector_info is None:
        return None

    # Convert to DataFrame
    df_traffic = pd.DataFrame(traffic_data)
    if df_traffic.empty:
        return None

    # Get the latest data for each detector
    df_latest = df_traffic.sort_values('last_updated').groupby('detector_id').last().reset_index()

    # Merge with detector info
    df_merged = pd.merge(
        df_latest,
        detector_info,
        left_on='detector_id',
        right_on='AID_ID_Number',
        how='inner'
    )

    if df_merged.empty:
        return None

    # Configure metric-specific settings
    metric_config = {
        "Speed": {
            "value_col": "speed",
            "label": "Speed (km/h)",
            "color_func": lambda x, max_val: [0, min(255, int(x / max_val * 255)), 0, 160],
            "size_func": lambda x: x * 2
        },
        "Volume": {
            "value_col": "volume",
            "label": "Volume (vehicles)",
            "color_func": lambda x, max_val: [0, 0, min(255, int(x / max_val * 255)), 160],
            "size_func": lambda x: x * 10
        },
        "Occupancy": {
            "value_col": "occupancy",
            "label": "Occupancy (%)",
            "color_func": lambda x, max_val: [min(255, int(x / max_val * 255)), 0, 0, 160],
            "size_func": lambda x: x * 10
        }
    }

    config = metric_config[metric]
    value_col = config["value_col"]

    # Apply configuration
    max_val = df_merged[value_col].max()
    df_merged['map_value'] = df_merged[value_col]
    df_merged['map_value_label'] = config["label"]
    df_merged['color'] = df_merged[value_col].apply(lambda x: config["color_func"](x, max_val))
    df_merged['size'] = df_merged[value_col].apply(lambda x: max(100, config["size_func"](x)))

    # Add info column for tooltip
    df_merged['info'] = df_merged.apply(
        lambda row: f"{row['detector_id']}: {row['Road_EN']} - {row[value_col]} {config['label'].split(' ')[1]}",
        axis=1
    )

    return df_merged


# -------------------------- MAIN APP --------------------------

try:
    # Connect to MongoDB
    client = get_mongo_client()
    db = client[DB_NAME]
    speed_collection = db[SPEED_COLLECTION]
    stats_collection = db[STATS_COLLECTION]
    st.success("✅ Connected to MongoDB")
except Exception as e:
    st.error(f"❌ Failed to connect to MongoDB: {e}")
    st.stop()

# Load detector info
detector_info = load_detector_info()
if detector_info is None:
    st.warning("Could not load detector information. Map visualization will not be available.")

# -------------------------- SIDEBAR --------------------------

st.sidebar.title("Dashboard Controls")

refresh_interval = st.sidebar.slider(
    "Auto-refresh interval (seconds)",
    min_value=5,
    max_value=60,
    value=30,
    step=5
)

time_range = st.sidebar.selectbox(
    "Time range for data",
    ["Last hour", "Last 6 hours", "Last 12 hours", "Last 24 hours", "All data"],
    index=0
)

# Map visualization options
st.sidebar.title("Map Visualization")
map_metric = st.sidebar.selectbox(
    "Metric to display on map",
    ["Speed", "Volume", "Occupancy"],
    index=0
)

# Time range mapping
time_filters = {
    "Last hour": datetime.now() - timedelta(hours=1),
    "Last 6 hours": datetime.now() - timedelta(hours=6),
    "Last 12 hours": datetime.now() - timedelta(hours=12),
    "Last 24 hours": datetime.now() - timedelta(hours=24),
    "All data": datetime.min
}

selected_time_filter = time_filters[time_range]

# -------------------------- TABS --------------------------

tab1, tab2, tab3 = st.tabs(["Data Collection Stats", "Traffic Data Analysis", "Traffic Map"])

# -------------------------- TAB 1: DATA COLLECTION STATS --------------------------

with tab1:
    # Auto-refresh message
    st.markdown(
        f"*Dashboard auto-refreshes every {refresh_interval} seconds. Last update: {datetime.now().strftime('%H:%M:%S')}*")

    # Get data
    stats_data = get_collection_stats(selected_time_filter)

    if not stats_data:
        st.warning("No collection statistics available for the selected time range")
    else:
        # Calculate metrics
        metrics = calculate_metrics(stats_data)

        # Display metrics in a row
        cols = st.columns(4)
        display_metric(cols[0], metrics['total_collections'], "Data Collections")
        display_metric(cols[1], metrics['total_records'], "Records Processed")
        display_metric(cols[2], metrics['total_inserts'], "New Records")
        display_metric(cols[3], metrics['total_updates'], "Updated Records")

        # Create a DataFrame for plotting
        df_stats = pd.DataFrame(stats_data)
        if not df_stats.empty:
            df_stats['timestamp'] = pd.to_datetime(df_stats['timestamp'])
            df_stats = df_stats.sort_values('timestamp')

            st.markdown("<h2 class='sub-header'>Data Collection Over Time</h2>", unsafe_allow_html=True)

            # Create time-series chart for records processed
            fig1 = px.line(
                df_stats,
                x='timestamp',
                y='records_processed',
                title='Records Processed per Collection',
                labels={'timestamp': 'Time', 'records_processed': 'Records Processed'}
            )
            fig1.update_layout(height=400)
            st.plotly_chart(fig1, use_container_width=True)

            # Create stacked bar chart for inserts vs updates
            df_melted = pd.melt(
                df_stats,
                id_vars=['timestamp'],
                value_vars=['records_inserted', 'records_updated'],
                var_name='Record Type',
                value_name='Count'
            )
            df_melted['Record Type'] = df_melted['Record Type'].replace({
                'records_inserted': 'New Records',
                'records_updated': 'Updated Records'
            })

            fig2 = px.bar(
                df_melted,
                x='timestamp',
                y='Count',
                color='Record Type',
                title='New vs Updated Records Over Time',
                labels={'timestamp': 'Time', 'Count': 'Number of Records'}
            )
            fig2.update_layout(height=400)
            st.plotly_chart(fig2, use_container_width=True)

            # Display raw data
            st.markdown("<h2 class='sub-header'>Recent Collection Stats</h2>", unsafe_allow_html=True)
            display_cols = ['timestamp', 'records_processed', 'records_inserted', 'records_updated']
            st.dataframe(
                df_stats[display_cols].sort_values('timestamp', ascending=False).head(10),
                use_container_width=True
            )

# -------------------------- TAB 2: TRAFFIC DATA ANALYSIS --------------------------

with tab2:
    # Auto-refresh message
    st.markdown(
        f"*Dashboard auto-refreshes every {refresh_interval} seconds. Last update: {datetime.now().strftime('%H:%M:%S')}*")

    # Get traffic data
    traffic_data = get_traffic_data(selected_time_filter)

    if not traffic_data:
        st.warning("No traffic data available for the selected time range")
    else:
        # Convert to DataFrame
        df_traffic = pd.DataFrame(traffic_data)

        # Display summary statistics
        st.markdown("<h2 class='sub-header'>Traffic Data Summary</h2>", unsafe_allow_html=True)

        # Count unique values
        unique_dates = df_traffic['date'].nunique()
        unique_detectors = df_traffic['detector_id'].nunique()
        unique_lanes = df_traffic['lane_id'].nunique()

        cols = st.columns(3)
        display_metric(cols[0], unique_dates, "Unique Dates")
        display_metric(cols[1], unique_detectors, "Unique Detectors")
        display_metric(cols[2], unique_lanes, "Unique Lanes")

        # Speed analysis
        st.markdown("<h2 class='sub-header'>Speed Analysis</h2>", unsafe_allow_html=True)
        lane_speed = df_traffic.groupby('lane_id')['speed'].mean().reset_index()
        fig3 = px.bar(
            lane_speed,
            x='lane_id',
            y='speed',
            title='Average Speed by Lane Type',
            labels={'lane_id': 'Lane Type', 'speed': 'Average Speed (km/h)'},
            color='lane_id'
        )
        fig3.update_layout(height=400)
        st.plotly_chart(fig3, use_container_width=True)

        # Traffic volume analysis
        st.markdown("<h2 class='sub-header'>Traffic Volume Analysis</h2>", unsafe_allow_html=True)
        detector_volume = df_traffic.groupby('detector_id')['volume'].sum().reset_index()
        detector_volume = detector_volume.sort_values('volume', ascending=False).head(10)
        fig4 = px.bar(
            detector_volume,
            x='detector_id',
            y='volume',
            title='Total Traffic Volume by Detector (Top 10)',
            labels={'detector_id': 'Detector ID', 'volume': 'Total Volume'},
            color='volume',
            color_continuous_scale='Viridis'
        )
        fig4.update_layout(height=400)
        st.plotly_chart(fig4, use_container_width=True)

        # District analysis (if detector info is available)
        if detector_info is not None:
            merged_df = pd.merge(
                df_traffic,
                detector_info,
                left_on='detector_id',
                right_on='AID_ID_Number',
                how='inner'
            )

            if not merged_df.empty:
                st.markdown("<h2 class='sub-header'>District Analysis</h2>", unsafe_allow_html=True)

                # Group by district
                district_stats = merged_df.groupby('District').agg({
                    'speed': 'mean',
                    'volume': 'sum',
                    'occupancy': 'mean'
                }).reset_index()

                # Create district analysis charts
                district_tabs = st.tabs(['Speed by District', 'Volume by District', 'Occupancy by District'])

                metrics = [
                    {"col": "speed", "title": "Average Speed by District", "label": "Average Speed (km/h)"},
                    {"col": "volume", "title": "Total Traffic Volume by District", "label": "Total Volume"},
                    {"col": "occupancy", "title": "Average Occupancy by District", "label": "Average Occupancy (%)"}
                ]

                for i, metric in enumerate(metrics):
                    with district_tabs[i]:
                        fig = px.bar(
                            district_stats.sort_values(metric["col"], ascending=False),
                            x='District',
                            y=metric["col"],
                            title=metric["title"],
                            labels={'District': 'District', metric["col"]: metric["label"]},
                            color='District'
                        )
                        fig.update_layout(height=400)
                        st.plotly_chart(fig, use_container_width=True)

        # Display raw data sample
        st.markdown("<h2 class='sub-header'>Raw Traffic Data Sample</h2>", unsafe_allow_html=True)
        display_cols = ['date', 'period_from', 'period_to', 'detector_id', 'lane_id', 'speed', 'volume', 'last_updated']
        st.dataframe(
            df_traffic[display_cols].sort_values('last_updated', ascending=False).head(10),
            use_container_width=True
        )

# -------------------------- TAB 3: TRAFFIC MAP --------------------------

# -------------------------- TAB 3: TRAFFIC MAP --------------------------

with tab3:
    # Auto-refresh message
    st.markdown(
        f"*Dashboard auto-refreshes every {refresh_interval} seconds. Last update: {datetime.now().strftime('%H:%M:%S')}*")

    # Get traffic data for map
    traffic_data = get_traffic_data(selected_time_filter)

    if not traffic_data:
        st.warning("No traffic data available for the selected time range")
    elif detector_info is None:
        st.warning("Detector location information is not available. Cannot display map.")
    else:
        # Prepare map data
        map_data = prepare_map_data(traffic_data, detector_info, map_metric)

        if map_data is not None and not map_data.empty:
            st.markdown("<h2 class='sub-header'>Traffic Data Heat Map</h2>", unsafe_allow_html=True)

            # Map explanation
            st.markdown(f"""
            <div style='background-color: #f0f2f6; padding: 1rem; border-radius: 10px; margin-bottom: 1rem;'>
                <h3>Heat Map Information</h3>
                <p>This heat map shows the {map_metric.lower()} data from traffic detectors across Hong Kong.</p>
                <ul>
                    <li>Areas with higher intensity (red) represent higher {map_metric.lower()} values.</li>
                    <li>Areas with lower intensity (blue) represent lower {map_metric.lower()} values.</li>
                    <li>Click on the map to explore and zoom in to specific areas.</li>
                </ul>
            </div>
            """, unsafe_allow_html=True)

            # Determine the value column based on the selected metric
            value_col = "speed" if map_metric == "Speed" else "volume" if map_metric == "Volume" else "occupancy"

            try:
                # Import leafmap
                import leafmap.foliumap as leafmap
                import pandas as pd

                # Create a proper DataFrame for the heat map with correct column names
                heat_df = map_data[['Latitude', 'Longitude', value_col]].copy()

                # Ensure all values are numeric
                heat_df[value_col] = pd.to_numeric(heat_df[value_col], errors='coerce')

                # Drop any rows with NaN values
                heat_df = heat_df.dropna()

                # Rename columns to match what leafmap expects
                heat_df.columns = ["latitude", "longitude", "value"]

                # Create the map centered on Hong Kong
                m = leafmap.Map(center=[22.3193, 114.1694], zoom=11)

                # Add the heat map layer directly using the DataFrame
                m.add_heatmap(
                    heat_df,
                    latitude="latitude",
                    longitude="longitude",
                    value="value",
                    name=f"{map_metric} Heat Map",
                    radius=20,
                )

                # Display the map
                m.to_streamlit(height=600)

                # # Add a legend for the heat map
                # st.markdown(f"""
                # <div style='background-color: #f0f2f6; padding: 1rem; border-radius: 10px; margin-top: 1rem;'>
                #     <h3>Heat Map Legend</h3>
                #     <div style='display: flex; align-items: center;'>
                #         <div style='background: linear-gradient(to right,
                #             blue,
                #             cyan,
                #             lime,
                #             yellow,
                #             orange,
                #             red);
                #             width: 100%; height: 20px; border-radius: 5px;'>
                #         </div>
                #     </div>
                #     <div style='display: flex; justify-content: space-between; margin-top: 5px;'>
                #         <span>Low {map_metric}</span>
                #         <span>High {map_metric}</span>
                #     </div>
                # </div>
                # """, unsafe_allow_html=True)

            except Exception as e:
                st.error(f"Error creating heat map: {e}")

            # Display metric-specific information based on the selected metric
            st.markdown(f"<h3 class='sub-header'>{map_metric} Statistics</h3>", unsafe_allow_html=True)

            # Configure metric-specific stats display
            if map_metric == "Speed":
                cols = st.columns(3)
                display_metric(cols[0], f"{map_data['speed'].mean():.1f}", "Average Speed (km/h)")
                display_metric(cols[1], f"{map_data['speed'].max():.1f}", "Maximum Speed (km/h)")
                display_metric(cols[2], f"{map_data['speed'].min():.1f}", "Minimum Speed (km/h)")
            elif map_metric == "Volume":
                cols = st.columns(3)
                display_metric(cols[0], f"{map_data['volume'].sum()}", "Total Volume (vehicles)")
                display_metric(cols[1], f"{map_data['volume'].mean():.1f}", "Average Volume (vehicles)")
                display_metric(cols[2], f"{map_data['volume'].max()}", "Maximum Volume (vehicles)")
            else:  # Occupancy
                cols = st.columns(3)
                display_metric(cols[0], f"{map_data['occupancy'].mean():.1f}", "Average Occupancy (%)")
                display_metric(cols[1], f"{map_data['occupancy'].max():.1f}", "Maximum Occupancy (%)")
                display_metric(cols[2], f"{map_data['occupancy'].min():.1f}", "Minimum Occupancy (%)")

            # Display top detectors table based on selected metric
            st.markdown("<h3 class='sub-header'>Top Detectors by Current Values</h3>", unsafe_allow_html=True)

            # Set up display settings based on the metric
            display_config = {
                "Speed": {
                    "cols": ['detector_id', 'Road_EN', 'speed', 'Direction', 'lane_id'],
                    "label": "Speed (km/h)"
                },
                "Volume": {
                    "cols": ['detector_id', 'Road_EN', 'volume', 'Direction', 'lane_id'],
                    "label": "Volume (vehicles)"
                },
                "Occupancy": {
                    "cols": ['detector_id', 'Road_EN', 'occupancy', 'Direction', 'lane_id'],
                    "label": "Occupancy (%)"
                }
            }

            config = display_config[map_metric]
            display_cols = config["cols"]
            top_detectors = map_data.sort_values(value_col, ascending=False).head(10)

            # Create a bar chart for top detectors
            fig_top = px.bar(
                top_detectors,
                x='detector_id',
                y=value_col,
                title=f'Top 10 Detectors by {map_metric}',
                labels={'detector_id': 'Detector ID', value_col: config["label"]},
                color=value_col,
                color_continuous_scale="Viridis",
                hover_data=['Road_EN', 'Direction', 'lane_id']
            )
            fig_top.update_layout(height=400)
            st.plotly_chart(fig_top, use_container_width=True)

            # Display table of top detectors
            st.dataframe(top_detectors[display_cols], use_container_width=True)

            # Show detector data table with search/filter capability
            st.markdown("<h3 class='sub-header'>Search Detector Data</h3>", unsafe_allow_html=True)

            # Search by detector ID or road name
            search_options = st.columns([2, 2, 1])
            search_term = search_options[0].text_input("Search by Detector ID or Road Name")
            selected_district = search_options[1].selectbox(
                "Filter by District",
                options=["All Districts"] + list(map_data['District'].unique())
            )
            row_count = search_options[2].number_input("Rows to display", min_value=5, max_value=100, value=10, step=5)

            # Apply filters
            filtered_data = map_data.copy()

            if search_term:
                filtered_data = filtered_data[
                    (filtered_data['detector_id'].str.contains(search_term, case=False)) |
                    (filtered_data['Road_EN'].str.contains(search_term, case=False))
                    ]

            # Apply district filter
            if selected_district != "All Districts":
                filtered_data = filtered_data[filtered_data['District'] == selected_district]

            # Sort by the selected metric
            filtered_data = filtered_data.sort_values(value_col, ascending=False)

            # Display the filtered data
            display_cols = ['detector_id', 'District', 'Road_EN', value_col, 'Direction', 'lane_id', 'Latitude',
                            'Longitude']
            st.dataframe(filtered_data[display_cols].head(row_count), use_container_width=True)

            # Show filtered results on a map if not too many
            if not filtered_data.empty and len(filtered_data) <= 50:
                st.markdown("<h3 class='sub-header'>Filtered Results Map</h3>", unsafe_allow_html=True)

                try:
                    # Create a DataFrame for filtered data with proper column names
                    filtered_heat_df = filtered_data[['Latitude', 'Longitude', value_col]].copy()
                    filtered_heat_df[value_col] = pd.to_numeric(filtered_heat_df[value_col], errors='coerce')
                    filtered_heat_df = filtered_heat_df.dropna()
                    filtered_heat_df.columns = ["latitude", "longitude", "value"]

                    # Create filtered map with leafmap
                    filtered_map = leafmap.Map(
                        center=[filtered_data['Latitude'].mean(), filtered_data['Longitude'].mean()],
                        zoom=13
                    )

                    # Add heat map layer
                    filtered_map.add_heatmap(
                        filtered_heat_df,
                        latitude="latitude",
                        longitude="longitude",
                        value="value",
                        name=f"Filtered {map_metric} Heat Map",
                        radius=25
                    )

                    # Display filtered map
                    filtered_map.to_streamlit(height=500)

                except Exception as e:
                    st.error(f"Error creating filtered heat map: {e}")

                    # Fallback to Plotly for filtered view
                    fig = px.scatter_mapbox(
                        filtered_data,
                        lat="Latitude",
                        lon="Longitude",
                        color=value_col,
                        color_continuous_scale="Jet",
                        size=value_col,
                        size_max=15,
                        zoom=12,
                        hover_name="detector_id",
                        hover_data=["Road_EN", value_col, "District", "Direction"],
                        title=f"Filtered {map_metric} Map",
                        mapbox_style="carto-positron"
                    )

                    fig.update_layout(
                        height=500,
                        margin={"r": 0, "t": 30, "l": 0, "b": 0}
                    )

                    st.plotly_chart(fig, use_container_width=True)

            elif len(filtered_data) > 50:
                st.info("Too many locations to show on filtered map. Please refine your search to see locations.")

# Auto-refresh if enabled
if refresh_interval and not st.session_state.get('replay_running', False):
    time.sleep(60)  # Small delay to prevent constant refreshing
    st.rerun()
